package com.krakatau88.samplekrakatau88ads;

public class SettingAds {
    public static String SELECT_ADS ="APPLOVIN-M";
    public static String BACKUP_ADS = "IRON";

    public static String MAIN_ADS_BANNER ="topBanner";
    public static String BACKUP_ADS_BANNER="topBanner";

    public static String MAIN_ADS_INTERTITIAL ="Android_Interstitial";
    public static String BACKUP_ADS_INTERTITIAL="Android_Interstitial";

    public static String MAIN_ADS_REWARDS ="Rewarded_Android";
    public static String BACKUP_ADS_REWARDS="Rewarded_Android";

    public static String OPEN_ADS_ADMOB ="ca-app-pub-3940256099942544/3419835294x";
    public static String NATIVE_ADS_ADMOB ="ca-app-pub-3940256099942544/2247696110";
    public static String INITIALIZE_SDK = "4532643";
    public static String INITIALIZE_SDK_BACKUPADS = "123456";

    public static String HIGH_PAYING_KEYWORD1="Finance";
    public static String HIGH_PAYING_KEYWORD2="";
    public static String HIGH_PAYING_KEYWORD3="";
    public static String HIGH_PAYING_KEYWORD4="";
    public static String HIGH_PAYING_KEYWORD5="";

    public static int INTERVAL = 0;
        /*
    APPLOVIN_BANNER = "db4d5e8718b97d78";
    APPLOVIN_INTER = "518cd97722c60b52";

    BANNER_MOPUB = "b195f8dd8ded45fe847ad89ed1d016da";
    INTER_MOPUB = "24534e1901884e398f1253216226017e";

    ADMOB_INTER = "ca-app-pub-3940256099942544/1033173712";
    ADMOB_BANNER = "ca-app-pub-3940256099942544/6300978111";
    ADMOB_OPENAD ="ca-app-pub-3940256099942544/3419835294"

    IRON_BANNER="DefaultBanner";
    IRON_INTERTITIAL="Game_Screen";
    IRON_REWARD="DefaultRewardedVideo
    IRON_APPID="107355779";

    STARTAPPID="123456789";

    FAN_BANNER = " MG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"



  private String unityGameID = "1234567";
  private Boolean testMode = true;
  private String adUnitId = "video";
  interstitialAdUnitId

    private String unityGameID = "1234567";
  private Boolean testMode = true;
  private String adUnitId = "rewardedVideo";
rewardedAdUnitId

 String unityGameID = "1234567";
  Boolean testMode = true;
  String topAdUnitId = "topBanner";
  String bottomAdUnitId = "bottomBanner";
     */




}
